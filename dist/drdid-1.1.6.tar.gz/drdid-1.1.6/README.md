# DRDID in python

See the original [`R package`](https://github.com/pedrohcgs/DRDID/tree/master)

## Installation

```
pip install git+https://github.com/d2cml-ai/DRDID
```
